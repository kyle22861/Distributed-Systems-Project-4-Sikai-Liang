package edu.cmu.andrewid.cryptotracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AutoCompleteTextView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL =
            "http://10.0.2.2:8080/CryptoService_war_exploded/api/price";

    private static final String SYMBOLS_URL =
            "http://10.0.2.2:8080/CryptoService_war_exploded/api/symbols";

    private AutoCompleteTextView symbolInput;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        symbolInput = findViewById(R.id.symbolInput);
        resultText = findViewById(R.id.resultText);
        Button fetchButton = findViewById(R.id.fetchButton);

        loadSymbols();

        fetchButton.setOnClickListener(v -> {
            String symbol = symbolInput.getText().toString().trim().toUpperCase();
            if (symbol.isEmpty()) {
                Toast.makeText(this, "Please enter a symbol", Toast.LENGTH_SHORT).show();
                return;
            }
            fetchPrice(symbol);
        });
    }

    private void loadSymbols() {
        new Thread(() -> {
            try {
                URL url = new URL(SYMBOLS_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);

                JSONArray arr = new JSONArray(sb.toString());

                String[] symbols = new String[arr.length()];
                for (int i = 0; i < arr.length(); i++)
                    symbols[i] = arr.getString(i);

                runOnUiThread(() -> {
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(
                            this,
                            android.R.layout.simple_dropdown_item_1line,
                            symbols
                    );
                    symbolInput.setAdapter(adapter);
                });

            } catch (Exception e) {
                runOnUiThread(() ->
                        Toast.makeText(this, "Failed to load symbols", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }

    private void fetchPrice(final String symbol) {
        resultText.setText("Loading…");

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String encodedSymbol = URLEncoder.encode(symbol, "UTF-8");
                String urlStr = BASE_URL + "?symbol=" + encodedSymbol;

                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                int code = conn.getResponseCode();
                if (code != HttpURLConnection.HTTP_OK) {
                    setText("Server error: " + code);
                    return;
                }

                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);

                JSONObject obj = new JSONObject(sb.toString());

                String price = obj.optString("price", "N/A");
                String high = obj.optString("high", "N/A");
                String low = obj.optString("low", "N/A");
                String volume = obj.optString("volume", "N/A");
                long timestamp = obj.optLong("timestamp", 0L);

                String display = "Symbol: " + symbol +
                        "\nPrice: " + price +
                        "\nHigh: " + high +
                        "\nLow: " + low +
                        "\nVolume: " + volume +
                        "\nTimestamp: " + timestamp;

                setText(display);

            } catch (Exception e) {
                setText("Error: " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void setText(final String text) {
        runOnUiThread(() -> resultText.setText(text));
    }
}
