package edu.cmu.andrewid.crypto;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Author: Sikai Liang
 * Andrew id: skyl
 * DashboardServlet creates analytics for administrators:
 *    GET /dashboard
 * Reads logs from MongoDB
 * Computes analytics (total requests, top symbols, latest symbol)
 * Passes all data to dashboard.jsp for rendering
 */
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        MongoCollection<Document> col = MongoLogger.getCollection();

        FindIterable<Document> cursor =
                col.find().sort(Sorts.descending("timestamp")).limit(50);

        List<Document> logs = new ArrayList<>();
        for (Document d : cursor) {
            logs.add(d);
        }

        long totalRequests = col.countDocuments();

        Map<String, Integer> countBySymbol = new HashMap<>();
        for (Document d : logs) {
            String symbol = d.getString("symbol");
            if (symbol == null) continue;
            countBySymbol.put(symbol, countBySymbol.getOrDefault(symbol, 0) + 1);
        }

        List<Map.Entry<String, Integer>> entries =
                new ArrayList<>(countBySymbol.entrySet());
        entries.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        List<Document> topSymbols = new ArrayList<>();
        int limit = Math.min(5, entries.size());
        for (int i = 0; i < limit; i++) {
            Map.Entry<String, Integer> e = entries.get(i);
            topSymbols.add(new Document("symbol", e.getKey())
                    .append("count", e.getValue()));
        }

        String lastSymbol = logs.isEmpty() ? "N/A" :
                logs.get(0).getString("symbol");

        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("uniqueSymbols", countBySymbol.size());
        req.setAttribute("lastSymbol", lastSymbol);
        req.setAttribute("topSymbols", topSymbols);
        req.setAttribute("logs", logs);

        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}
