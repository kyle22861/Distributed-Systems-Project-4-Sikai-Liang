package edu.cmu.andrewid.crypto;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

/**
 * Author: Sikai Liang
 * Andrew id: skyl
 * Simple MongoDB helper class used to log every API request.
 * We reuse one MongoClient + one collection for the entire lifetime
 * of the TomEE web application.
 */
public class MongoLogger {

    private static final String URI =
            "mongodb+srv://Sikai:1234@cluster0.p9mvpt9.mongodb.net/cryptologs?retryWrites=true&w=majority";

    private static final String DB_NAME = "cryptologs";
    private static final String COLLECTION_NAME = "requests";

    private static final MongoClient client = MongoClients.create(URI);
    private static final MongoDatabase db = client.getDatabase(DB_NAME);
    private static final MongoCollection<Document> collection =
            db.getCollection(COLLECTION_NAME);

    public static void log(Document doc) {
        collection.insertOne(doc);
    }

    public static MongoCollection<Document> getCollection() {
        return collection;
    }
}
