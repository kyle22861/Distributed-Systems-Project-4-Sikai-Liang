package edu.cmu.andrewid.crypto;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet("/api/symbols")
public class CryptoSymbolsServlet extends HttpServlet {
    /**
     * Author: Sikai
     * Andrew id: skyl
     * CryptoSymbolsServlet provides a list of ALL available crypto symbols.
     * Android app calls:
     *   GET /api/symbols
     * This is used to prefill the AutoComplete dropdown in the UI.
     */

    private static final String SYMBOLS_URL =
            "https://api.exchange.cryptomkt.com/api/3/public/ticker";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        try {
            URL url = new URL(SYMBOLS_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            if (conn.getResponseCode() != 200) {
                out.print(new JSONObject().put("error", "Crypto API returned code " + conn.getResponseCode()));
                return;
            }

            BufferedReader reader =
                    new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);

            JSONObject full = new JSONObject(json.toString());
            JSONArray arr = new JSONArray();

            for (String key : full.keySet()) {
                arr.put(key);
            }

            out.print(arr.toString());

        } catch (Exception e) {
            out.print(new JSONObject().put("error", e.getMessage()));
        }
    }
}
