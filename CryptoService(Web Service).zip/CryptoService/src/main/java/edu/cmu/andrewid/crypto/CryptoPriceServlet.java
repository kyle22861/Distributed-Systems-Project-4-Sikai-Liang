package edu.cmu.andrewid.crypto;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import org.bson.Document;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

public class CryptoPriceServlet extends HttpServlet {
    /**
     * Author: Sikai Liang
     * Andrew id: skyl
     * CryptoPriceServlet handles requests from the Android app
     * Validates the symbol parameter
     * Fetches real-time price data from CryptoMKT public API
     * Returns JSON response for the Android app
     * Logs every request to MongoDB (via MongoLogger)
     */

    private static final String API_URL =
            "https://api.exchange.cryptomkt.com/api/3/public/ticker";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String symbol = req.getParameter("symbol");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();

        if (symbol == null || symbol.isEmpty()) {
            JSONObject err = new JSONObject().put("error", "Missing symbol");
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print(err.toString());

            Document logDoc = new Document("timestamp", new Date())
                    .append("symbol", symbol)
                    .append("clientIp", req.getRemoteAddr())
                    .append("userAgent", req.getHeader("User-Agent"))
                    .append("apiUrl", API_URL)
                    .append("apiStatus", -1)
                    .append("apiTimeMs", 0)
                    .append("statusToClient", resp.getStatus())
                    .append("errorMessage", "Missing symbol");
            MongoLogger.log(logDoc);
            return;
        }

        HttpURLConnection conn = null;
        long start = System.currentTimeMillis();

        try {
            URL url = new URL(API_URL);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int code = conn.getResponseCode();
            long apiTimeMs = System.currentTimeMillis() - start;

            if (code != HttpURLConnection.HTTP_OK) {
                JSONObject err = new JSONObject()
                        .put("error", "Crypto API returned code " + code);
                resp.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
                out.print(err.toString());

                Document logDoc = new Document("timestamp", new Date())
                        .append("symbol", symbol)
                        .append("clientIp", req.getRemoteAddr())
                        .append("userAgent", req.getHeader("User-Agent"))
                        .append("apiUrl", API_URL)
                        .append("apiStatus", code)
                        .append("apiTimeMs", apiTimeMs)
                        .append("statusToClient", resp.getStatus())
                        .append("price", null)
                        .append("high", null)
                        .append("low", null)
                        .append("volume", null);
                MongoLogger.log(logDoc);
                return;
            }

            BufferedReader br =
                    new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder json = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) json.append(line);

            JSONObject allTickers = new JSONObject(json.toString());

            if (!allTickers.has(symbol)) {
                JSONObject err = new JSONObject()
                        .put("error", "Symbol not found in ticker list");
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print(err.toString());

                Document logDoc = new Document("timestamp", new Date())
                        .append("symbol", symbol)
                        .append("clientIp", req.getRemoteAddr())
                        .append("userAgent", req.getHeader("User-Agent"))
                        .append("apiUrl", API_URL)
                        .append("apiStatus", code)
                        .append("apiTimeMs", apiTimeMs)
                        .append("statusToClient", resp.getStatus())
                        .append("errorMessage", "Symbol not found");
                MongoLogger.log(logDoc);
                return;
            }

            JSONObject data = allTickers.getJSONObject(symbol);

            String last = data.optString("last");
            String open = data.optString("open");
            String high = data.optString("high");
            String low = data.optString("low");
            String volume = data.optString("volume");
            long timestamp = System.currentTimeMillis();

            JSONObject result = new JSONObject();
            result.put("symbol", symbol);
            result.put("price", last);
            result.put("open", open);
            result.put("high", high);
            result.put("low", low);
            result.put("volume", volume);
            result.put("timestamp", timestamp);

            resp.setStatus(HttpServletResponse.SC_OK);
            out.print(result.toString());

            Document logDoc = new Document("timestamp", new Date())
                    .append("symbol", symbol)
                    .append("clientIp", req.getRemoteAddr())
                    .append("userAgent", req.getHeader("User-Agent"))
                    .append("apiUrl", API_URL)
                    .append("apiStatus", code)
                    .append("apiTimeMs", apiTimeMs)
                    .append("statusToClient", resp.getStatus())
                    .append("price", last)
                    .append("high", high)
                    .append("low", low)
                    .append("volume", volume);
            MongoLogger.log(logDoc);

        } catch (Exception e) {
            long apiTimeMs = System.currentTimeMillis() - start;
            JSONObject err = new JSONObject()
                    .put("error", "Exception: " + e.getMessage());
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(err.toString());

            Document logDoc = new Document("timestamp", new Date())
                    .append("symbol", symbol)
                    .append("clientIp", req.getRemoteAddr())
                    .append("userAgent", req.getHeader("User-Agent"))
                    .append("apiUrl", API_URL)
                    .append("apiStatus", -1)
                    .append("apiTimeMs", apiTimeMs)
                    .append("statusToClient", resp.getStatus())
                    .append("errorMessage", e.getMessage());
            MongoLogger.log(logDoc);

        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
